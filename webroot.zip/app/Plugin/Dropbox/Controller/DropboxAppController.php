<?php
/**
 * Dropbox App Controller
 *
 * @package cakebox
 * @author Kyle Robinson Young <kyle at dontkry.com>
 * @copyright 2012 Kyle Robinson Young
 */
class DropboxAppController extends AppController {
}